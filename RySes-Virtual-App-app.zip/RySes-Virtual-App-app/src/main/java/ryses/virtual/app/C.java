package ryses.virtual.app;

public class C
{
}